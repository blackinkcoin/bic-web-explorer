#!/bin/bash
cd "$(dirname "$0")"
echo "Compilando y ejecutando nodo Guardian en macOS..."
if ! command -v cargo &> /dev/null; then
  echo "Instalando Rust/Cargo..."
  curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
  source $HOME/.cargo/env
fi
./bicd --data-dir .bic_ledger
