=== GUARDIÁN DE LA RED BICD PARA MACOS ===

Compatible con macOS Sonoma, Ventura y anteriores (M1/M2/M3/M4 & Intel x86_64).
Ejecuta ./iniciar_guardian_mac.sh en tu Terminal.
