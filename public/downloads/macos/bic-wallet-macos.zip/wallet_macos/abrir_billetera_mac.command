#!/bin/bash
cd "$(dirname "$0")"
open billetera_fria_offline.html
