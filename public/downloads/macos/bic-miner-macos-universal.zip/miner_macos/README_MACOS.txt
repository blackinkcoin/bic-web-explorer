=== MINERO BLACK INK COIN PARA MACOS (APPLE SILICON & INTEL) ===

1. Haz doble clic en 'iniciar_minero_mac.command'.
(Si macOS indica que es de un desarrollador no identificado, ve a Ajustes de Sistema -> Privacidad y Seguridad -> Abrir de todos modos).
2. Pulsa espacio en la Terminal para inyectar entropía humana.
