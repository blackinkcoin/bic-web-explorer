#!/bin/bash
cd "$(dirname "$0")"
echo "Iniciando Minero Black Ink Coin en macOS..."
python3 -m pip install -r requirements.txt
python3 bic_miner_desktop.py
