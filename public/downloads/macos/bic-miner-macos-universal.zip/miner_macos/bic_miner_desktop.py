#!/usr/bin/env python3
"""
================================================================================
  BLACK INK COIN (BIC) — OFFICIAL DESKTOP MINER (SOVEREIGN LAYER 1)
  Multi-Threaded CPU Engine + Human Presence Touch Sensor + ESP32 Serial Monitor
================================================================================
"""

import os
import sys
import time
import json
import struct
import hashlib
import socket
import threading
import urllib.request
import urllib.error
from datetime import datetime

try:
    import tkinter as tk
    from tkinter import ttk, messagebox, scrolledtext
except ImportError:
    print("Error: tkinter is required to run the Desktop Miner. Install python3-tk.")
    sys.exit(1)

# Optional serial support for monitoring ESP32
try:
    import serial
    import serial.tools.list_ports
    HAS_SERIAL = True
except ImportError:
    HAS_SERIAL = False

# Default Configuration
DEFAULT_NODE_URL = "http://127.0.0.1:6660"
DEFAULT_ADDRESS = "bic666_440fa0a9c07544082f1bd22a7cae1115d033347ef07f4d44699d1068fc4545140c416a62f1d39ea7c5d66e9968e025f3ddfa2a6ff75250bbc05a75829e76df46"
TARGET_VALIDITY_WINDOW = 120 # Seconds of human touch validity

def check_difficulty_bits(h_bytes, zero_bits):
    full_bytes = zero_bits // 8
    rem_bits = zero_bits % 8
    for i in range(full_bytes):
        if h_bytes[i] != 0:
            return False
    if rem_bits > 0 and full_bytes < len(h_bytes):
        mask = (0xFF << (8 - rem_bits)) & 0xFF
        if (h_bytes[full_bytes] & mask) != 0:
            return False
    return True

def format_time_human(seconds):
    try:
        s = int(seconds)
    except (ValueError, TypeError):
        return f"{seconds}s"
    if s < 60:
        return f"{s}s"
    elif s < 3600:
        return f"{s // 60}m {s % 60}s"
    elif s < 86400:
        return f"{(s / 3600):.1f}h"
    elif s < 365 * 86400:
        return f"{(s / 86400):.1f}d"
    else:
        return f"{(s / (365 * 86400)):.2f}y"


class BicDesktopMinerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Black Ink Coin — Official Desktop Miner v0.666")
        self.root.geometry("980x740")
        self.root.minsize(860, 640)
        self.root.configure(bg="#0c0d12")

        # Mining State
        self.is_mining = False
        self.threads_count = max(1, min(os.cpu_count() or 4, 8))
        self.miner_threads = []
        self.total_hashes = 0
        self.blocks_mined = 0
        self.start_time = 0
        self.current_hashrate = 0.0
        self.hashrate_history = [0.0] * 30
        
        # Human Presence State (Solution 1)
        self.last_human_touch = time.time()
        self.touch_entropy_accumulator = 1337
        self.is_touch_key_held = False
        
        # Current Job
        self.current_job = None
        self.current_height = 0
        self.current_zeros = 2
        self.current_diff_bits = 16
        self.current_reward = 6.66
        self.tier_name = "Estándar"
        self.challenge_bytes = b"\x00" * 32
        self.touch_challenge_str = ""
        self.server_time_sync = 0
        self.server_time_fetch_local = 0
        self.nonce_counter = 0

        # Collaborative Mining Round State
        self.round_duration = 30
        self.round_time_remaining = 30
        self.active_miners_count = 0
        self.your_shares = 0

        # Anti-Sybil Cooldown & Submission Controls
        self.cooldown_until = 0.0
        self.submit_lock = threading.Lock()
        self.last_solved_height = 0
        self.last_cooldown_log = 0.0

        # ESP32 Serial Monitor State
        self.serial_conn = None
        self.serial_thread = None
        self.serial_running = False

        self._setup_styles()
        self._build_ui()
        self._start_background_loops()

    def _setup_styles(self):
        self.style = ttk.Style()
        self.style.theme_use("clam")
        
        # Configure TTK widgets colors
        self.style.configure(".", background="#0c0d12", foreground="#e6e8f0", font=("Helvetica", 10))
        self.style.configure("TFrame", background="#0c0d12")
        self.style.configure("Card.TFrame", background="#141620", relief="flat")
        self.style.configure("TLabel", background="#0c0d12", foreground="#e6e8f0")
        self.style.configure("Card.TLabel", background="#141620", foreground="#e6e8f0")
        
        self.style.configure("Accent.TButton", font=("Helvetica", 10, "bold"), background="#ff2a44", foreground="#ffffff", borderwidth=0)
        self.style.map("Accent.TButton", background=[("active", "#d91e36"), ("disabled", "#3a1c22")])

    def _build_ui(self):
        # 1. Header Bar
        header = tk.Frame(self.root, bg="#12131b", height=64, bd=0, highlightthickness=1, highlightbackground="#251419")
        header.pack(fill="x", side="top", padx=0, pady=0)

        title_box = tk.Frame(header, bg="#12131b")
        title_box.pack(side="left", padx=16, pady=10)

        badge_666 = tk.Label(title_box, text="666", font=("Cinzel", 15, "bold"), fg="#ff2a44", bg="#12131b")
        badge_666.pack(side="left", padx=(0, 10))

        title_text = tk.Label(title_box, text="BLACK INK COIN", font=("Helvetica", 13, "bold"), fg="#ffffff", bg="#12131b")
        title_text.pack(anchor="w")

        sub_text = tk.Label(title_box, text="DESKTOP SOVEREIGN CPU MINER (PROT. 0.666)", font=("Helvetica", 8), fg="#ff6677", bg="#12131b")
        sub_text.pack(anchor="w")

        # Daemon Connection Pill
        daemon_box = tk.Frame(header, bg="#12131b")
        daemon_box.pack(side="right", padx=16, pady=12)

        self.lbl_daemon_status = tk.Label(daemon_box, text="● NODE: CONNECTING...", font=("Monospace", 9, "bold"), fg="#ffaa00", bg="#1b1c28", padx=10, pady=4)
        self.lbl_daemon_status.pack()

        # 2. Main Paned Body
        main_paned = tk.PanedWindow(self.root, orient="horizontal", bg="#0c0d12", bd=0, sashwidth=4, sashrelief="flat")
        main_paned.pack(fill="both", expand=True, padx=12, pady=10)

        # Left Column: Mining Engine & Controls
        left_col = tk.Frame(main_paned, bg="#0c0d12")
        main_paned.add(left_col, minsize=480, stretch="always")

        # Right Column: ESP32 Hardware Monitor & Logs
        right_col = tk.Frame(main_paned, bg="#0c0d12")
        main_paned.add(right_col, minsize=380, stretch="always")

        self._build_mining_panel(left_col)
        self._build_esp32_and_logs(right_col)

    def _build_mining_panel(self, parent):
        # Card 1: Wallet Destination
        card_wallet = tk.Frame(parent, bg="#141620", highlightthickness=1, highlightbackground="#2a1820", padx=12, pady=10)
        card_wallet.pack(fill="x", pady=(0, 8))

        lbl_w = tk.Label(card_wallet, text="🔑 DESTINATION SHIELDED ADDRESS (RECEIVES MINED REWARDS):", font=("Helvetica", 9, "bold"), fg="#ff8899", bg="#141620")
        lbl_w.pack(anchor="w", pady=(0, 4))

        self.ent_address = tk.Entry(card_wallet, bg="#0d0e14", fg="#00e5ff", insertbackground="#00e5ff", font=("Monospace", 8), bd=0, highlightthickness=1, highlightbackground="#331822")
        self.ent_address.insert(0, DEFAULT_ADDRESS)
        self.ent_address.pack(fill="x", ipady=4)

        w_btn_row = tk.Frame(card_wallet, bg="#141620")
        w_btn_row.pack(fill="x", pady=(6, 0))

        btn_paste = tk.Button(w_btn_row, text="📋 Paste from Clipboard", font=("Helvetica", 8), bg="#222533", fg="#ffffff", activebackground="#33384f", bd=0, padx=8, pady=2, command=self._paste_address)
        btn_paste.pack(side="left", padx=(0, 6))

        btn_default = tk.Button(w_btn_row, text="🔄 Test Wallet", font=("Helvetica", 8), bg="#222533", fg="#8899aa", activebackground="#33384f", bd=0, padx=8, pady=2, command=lambda: self._set_address(DEFAULT_ADDRESS))
        btn_default.pack(side="left")

        # Card 2: Human Touch Presence (Solution 1)
        card_touch = tk.Frame(parent, bg="#18141f", highlightthickness=1, highlightbackground="#441a24", padx=12, pady=10)
        card_touch.pack(fill="x", pady=(0, 8))

        touch_top = tk.Frame(card_touch, bg="#18141f")
        touch_top.pack(fill="x")

        tk.Label(touch_top, text="🖐️ PROOF OF HUMAN TOUCH (ANTI-BOT SYBIL)", font=("Helvetica", 9, "bold"), fg="#ffb800", bg="#18141f").pack(side="left")
        self.lbl_touch_timer = tk.Label(touch_top, text="[120s VALID]", font=("Monospace", 9, "bold"), fg="#00ff88", bg="#18141f")
        self.lbl_touch_timer.pack(side="right")

        # Big interactive Touch / Heartbeat button
        self.btn_touch = tk.Button(card_touch, text="🖐️ CLICK OR HOLD SPACEBAR HERE\n(Refreshes 120s Human Presence Validity)", font=("Helvetica", 10, "bold"), bg="#2c141d", fg="#ff4466", activebackground="#551a2a", activeforeground="#ffffff", bd=0, highlightthickness=1, highlightbackground="#ff2a44", pady=12, cursor="hand2")
        self.btn_touch.pack(fill="x", pady=6)
        self.btn_touch.bind("<ButtonPress-1>", self._on_touch_press)
        self.btn_touch.bind("<ButtonRelease-1>", self._on_touch_release)

        # Global Spacebar binding
        self.root.bind("<KeyPress-space>", self._on_space_press)
        self.root.bind("<KeyRelease-space>", self._on_space_release)

        # Card 3: Engine Controls & Live Stats
        card_stats = tk.Frame(parent, bg="#141620", highlightthickness=1, highlightbackground="#2a1820", padx=12, pady=10)
        card_stats.pack(fill="x", pady=(0, 8))

        # Thread slider & Start/Stop
        ctrl_row = tk.Frame(card_stats, bg="#141620")
        ctrl_row.pack(fill="x", pady=(0, 8))

        tk.Label(ctrl_row, text="CPU Threads:", font=("Helvetica", 9, "bold"), fg="#ffffff", bg="#141620").pack(side="left", padx=(0, 6))
        self.spn_threads = tk.Spinbox(ctrl_row, from_=1, to=max(1, os.cpu_count() or 8), width=3, bg="#0d0e14", fg="#ffffff", insertbackground="#ffffff", font=("Helvetica", 10, "bold"), bd=0)
        self.spn_threads.delete(0, "end")
        self.spn_threads.insert(0, str(self.threads_count))
        self.spn_threads.pack(side="left", padx=(0, 16))

        self.btn_toggle_mine = tk.Button(ctrl_row, text="▶ START CPU MINING", font=("Helvetica", 10, "bold"), bg="#00aa55", fg="#ffffff", activebackground="#00cc66", bd=0, padx=14, pady=4, cursor="hand2", command=self.toggle_mining)
        self.btn_toggle_mine.pack(side="left", fill="x", expand=True)

        # Stats Grid (2x2)
        grid_f = tk.Frame(card_stats, bg="#141620")
        grid_f.pack(fill="x", pady=4)

        # Box 1: Hashrate
        b1 = tk.Frame(grid_f, bg="#0f1118", padx=8, pady=6, highlightthickness=1, highlightbackground="#222533")
        b1.grid(row=0, column=0, sticky="nsew", padx=3, pady=3)
        tk.Label(b1, text="LIVE HASHRATE", font=("Helvetica", 7, "bold"), fg="#8899aa", bg="#0f1118").pack(anchor="w")
        self.lbl_hashrate = tk.Label(b1, text="0.0 H/s", font=("Monospace", 14, "bold"), fg="#00e5ff", bg="#0f1118")
        self.lbl_hashrate.pack(anchor="w")

        # Box 2: Target & Difficulty
        b2 = tk.Frame(grid_f, bg="#0f1118", padx=8, pady=6, highlightthickness=1, highlightbackground="#222533")
        b2.grid(row=0, column=1, sticky="nsew", padx=3, pady=3)
        tk.Label(b2, text="BLOCK # & DIFFICULTY", font=("Helvetica", 7, "bold"), fg="#8899aa", bg="#0f1118").pack(anchor="w")
        self.lbl_block_diff = tk.Label(b2, text="#0 (16 Bits)", font=("Monospace", 14, "bold"), fg="#ffb800", bg="#0f1118")
        self.lbl_block_diff.pack(anchor="w")

        # Box 3: Blocks Mined
        b3 = tk.Frame(grid_f, bg="#0f1118", padx=8, pady=6, highlightthickness=1, highlightbackground="#222533")
        b3.grid(row=1, column=0, sticky="nsew", padx=3, pady=3)
        tk.Label(b3, text="BLOCKS MINED (THIS SESSION)", font=("Helvetica", 7, "bold"), fg="#8899aa", bg="#0f1118").pack(anchor="w")
        self.lbl_blocks_mined = tk.Label(b3, text="0 BLOCKS", font=("Monospace", 14, "bold"), fg="#00ff88", bg="#0f1118")
        self.lbl_blocks_mined.pack(anchor="w")

        # Box 4: Block Reward
        b4 = tk.Frame(grid_f, bg="#0f1118", padx=8, pady=6, highlightthickness=1, highlightbackground="#222533")
        b4.grid(row=1, column=1, sticky="nsew", padx=3, pady=3)
        tk.Label(b4, text="REWARD / TIER", font=("Helvetica", 7, "bold"), fg="#8899aa", bg="#0f1118").pack(anchor="w")
        self.lbl_reward = tk.Label(b4, text="6.6600 BIC", font=("Monospace", 14, "bold"), fg="#ff2a44", bg="#0f1118")
        self.lbl_reward.pack(anchor="w")

        grid_f.columnconfigure(0, weight=1)
        grid_f.columnconfigure(1, weight=1)

        # Card 3b: Collaborative Round Status
        card_round = tk.Frame(card_stats, bg="#0d0f17", padx=8, pady=6, highlightthickness=1, highlightbackground="#222533")
        card_round.pack(fill="x", pady=(6, 0))

        round_top = tk.Frame(card_round, bg="#0d0f17")
        round_top.pack(fill="x")
        tk.Label(round_top, text="⏱️ RONDA COLABORATIVA:", font=("Helvetica", 8, "bold"), fg="#00e5ff", bg="#0d0f17").pack(side="left")
        self.lbl_round_timer = tk.Label(round_top, text="30s / 30s", font=("Monospace", 8, "bold"), fg="#ffffff", bg="#0d0f17")
        self.lbl_round_timer.pack(side="right")

        round_bot = tk.Frame(card_round, bg="#0d0f17")
        round_bot.pack(fill="x", pady=(2, 0))
        self.lbl_round_miners = tk.Label(round_bot, text="Mineros participando: 1 | Tus participaciones: 0", font=("Helvetica", 8), fg="#8899aa", bg="#0d0f17")
        self.lbl_round_miners.pack(side="left")

        # Card 4: Hashrate Graph (Mini Canvas)
        card_graph = tk.Frame(parent, bg="#141620", highlightthickness=1, highlightbackground="#2a1820", padx=8, pady=6)
        card_graph.pack(fill="both", expand=True)

        tk.Label(card_graph, text="📊 REAL-TIME HASHRATE CHART (H/s):", font=("Helvetica", 8, "bold"), fg="#8899aa", bg="#141620").pack(anchor="w")
        self.canvas_graph = tk.Canvas(card_graph, bg="#090a0e", height=90, bd=0, highlightthickness=0)
        self.canvas_graph.pack(fill="both", expand=True, pady=(4, 0))

    def _build_esp32_and_logs(self, parent):
        # 1. ESP32 USB Bridge Card
        card_esp = tk.Frame(parent, bg="#141620", highlightthickness=1, highlightbackground="#2a1820", padx=12, pady=8)
        card_esp.pack(fill="x", pady=(0, 8))

        esp_hdr = tk.Frame(card_esp, bg="#141620")
        esp_hdr.pack(fill="x", pady=(0, 4))
        tk.Label(esp_hdr, text="🔌 ESP32 HARDWARE MINER BRIDGE", font=("Helvetica", 9, "bold"), fg="#00e5ff", bg="#141620").pack(side="left")

        esp_ctrl = tk.Frame(card_esp, bg="#141620")
        esp_ctrl.pack(fill="x")

        self.cbo_serial = ttk.Combobox(esp_ctrl, values=["/dev/ttyUSB0", "/dev/ttyUSB1", "/dev/ttyACM0"], width=14)
        self.cbo_serial.set("/dev/ttyUSB0")
        self.cbo_serial.pack(side="left", padx=(0, 6))

        self.btn_serial = tk.Button(esp_ctrl, text="Connect ESP32", font=("Helvetica", 8, "bold"), bg="#222533", fg="#ffffff", activebackground="#33384f", bd=0, padx=8, pady=2, command=self.toggle_esp32_serial)
        self.btn_serial.pack(side="left")

        self.lbl_serial_stat = tk.Label(esp_ctrl, text="Disconnected", font=("Helvetica", 8), fg="#778899", bg="#141620")
        self.lbl_serial_stat.pack(side="left", padx=8)

        # 2. Terminal Console
        card_log = tk.Frame(parent, bg="#141620", highlightthickness=1, highlightbackground="#2a1820", padx=10, pady=8)
        card_log.pack(fill="both", expand=True)

        log_hdr = tk.Frame(card_log, bg="#141620")
        log_hdr.pack(fill="x", pady=(0, 4))
        tk.Label(log_hdr, text="📜 SYSTEM & MINER CONSOLE LOG:", font=("Helvetica", 9, "bold"), fg="#ffffff", bg="#141620").pack(side="left")
        
        btn_clear = tk.Button(log_hdr, text="Clear", font=("Helvetica", 8), bg="#222533", fg="#8899aa", activebackground="#33384f", bd=0, padx=6, pady=1, command=self._clear_log)
        btn_clear.pack(side="right")

        self.txt_log = scrolledtext.ScrolledText(card_log, bg="#08090d", fg="#d0d4e0", font=("Monospace", 8), bd=0, highlightthickness=0)
        self.txt_log.pack(fill="both", expand=True)
        self.txt_log.tag_config("green", foreground="#00ff88")
        self.txt_log.tag_config("cyan", foreground="#00e5ff")
        self.txt_log.tag_config("gold", foreground="#ffb800")
        self.txt_log.tag_config("orange", foreground="#ffaa00")
        self.txt_log.tag_config("red", foreground="#ff2a44")
        self.txt_log.tag_config("gray", foreground="#778899")

        self._log("Black Ink Coin Desktop Miner initialized.", "cyan")
        self._log("Ready to mine to sovereign shielded address.", "gray")

    def _log(self, text, tag="gray"):
        now = datetime.now().strftime("%H:%M:%S")
        self.txt_log.insert("end", f"[{now}] {text}\n", tag)
        self.txt_log.see("end")

    def _clear_log(self):
        self.txt_log.delete("1.0", "end")

    def _paste_address(self):
        try:
            val = self.root.clipboard_get().strip()
            if val.startswith("bic666_"):
                self.ent_address.delete(0, "end")
                self.ent_address.insert(0, val)
                self._log(f"Address updated from clipboard: {val[:20]}...", "cyan")
            else:
                messagebox.showwarning("Invalid Address", "Clipboard does not contain a valid bic666_ address.")
        except Exception:
            pass

    def _set_address(self, addr):
        self.ent_address.delete(0, "end")
        self.ent_address.insert(0, addr)
        self._log("Set to default test wallet address.", "gray")

    # Touch Heartbeat Handlers (Solution 1)
    def _on_touch_press(self, event=None):
        self.last_human_touch = time.time()
        self.touch_entropy_accumulator = ((self.touch_entropy_accumulator * 31) ^ (int(time.time() * 1000000) & 0xFFFF)) + 1
        self.btn_touch.config(bg="#ff2a44", fg="#ffffff", text="🔥 HUMAN TOUCH ACTIVE! 🔥\n(Mining at Full Hashrate)")
        self._update_touch_timer_ui()

    def _on_touch_release(self, event=None):
        self.btn_touch.config(bg="#2c141d", fg="#ff4466", text="🖐️ CLICK OR HOLD SPACEBAR HERE\n(Refreshes 120s Human Presence Validity)")

    def _on_space_press(self, event=None):
        # Don't trigger touch if typing in an entry
        if isinstance(self.root.focus_get(), tk.Entry):
            return
        if not self.is_touch_key_held:
            self.is_touch_key_held = True
            self._on_touch_press()

    def _on_space_release(self, event=None):
        if self.is_touch_key_held:
            self.is_touch_key_held = False
            self._on_touch_release()

    def _update_touch_timer_ui(self):
        rem = max(0, TARGET_VALIDITY_WINDOW - int(time.time() - self.last_human_touch))
        rem_cd = max(0, int(self.cooldown_until - time.time()))

        if rem_cd > 0:
            self.lbl_block_diff.config(text=f"#{self.current_height} (⏳ {rem_cd}s CD)", fg="#ffaa00")
        elif self.current_diff_bits > 0:
            self.lbl_block_diff.config(text=f"#{self.current_height} ({self.current_diff_bits} Bits)", fg="#ffb800")

        if rem > 0:
            self.lbl_touch_timer.config(text=f"[{rem}s VALID]", fg="#00ff88")
        else:
            self.lbl_touch_timer.config(text="[EXPIRED > 120s]", fg="#ff2a44")

    # Mining Execution
    def toggle_mining(self):
        if not self.is_mining:
            addr = self.ent_address.get().strip()
            if not addr.startswith("bic666_"):
                messagebox.showerror("Invalid Address", "Please provide a valid BIC shielded address starting with 'bic666_'.")
                return
            
            try:
                self.threads_count = int(self.spn_threads.get())
            except ValueError:
                self.threads_count = 2

            self.is_mining = True
            self.btn_toggle_mine.config(text="⏹ STOP MINING", bg="#d91e36", activebackground="#b0162a")
            self.start_time = time.time()
            self._log(f"Starting {self.threads_count} CPU mining threads...", "cyan")

            # Reset touch window to now
            self.last_human_touch = time.time()

            for t_idx in range(self.threads_count):
                th = threading.Thread(target=self._mining_worker, args=(t_idx,), daemon=True)
                self.miner_threads.append(th)
                th.start()
        else:
            self.is_mining = False
            self.btn_toggle_mine.config(text="▶ START CPU MINING", bg="#00aa55", activebackground="#00cc66")
            self.lbl_hashrate.config(text="0.0 H/s")
            self._log("CPU mining stopped.", "gray")

    def _fetch_mining_job(self):
        try:
            req = urllib.request.Request(f"{DEFAULT_NODE_URL}/api/mining/job", headers={"User-Agent": "BicDesktopMiner/0.666"})
            with urllib.request.urlopen(req, timeout=3) as resp:
                data = json.loads(resp.read().decode())
                self.current_job = data
                self.current_height = data.get("height", 1)
                self.current_zeros = data.get("target_zeros", 2)
                self.current_diff_bits = data.get("target_zero_bits", 16)
                self.current_reward = data.get("reward_bic", 6.66)
                self.tier_name = data.get("tier_name", "Estándar")
                self.server_time_sync = data.get("server_time", int(time.time()))
                self.server_time_fetch_local = time.time()

                # Parse challenge
                ch = data.get("challenge", [])
                if isinstance(ch, list):
                    self.challenge_bytes = bytes(ch)
                elif isinstance(ch, str):
                    self.challenge_bytes = bytes.fromhex(ch)

                # Parse touch challenge
                tch = data.get("touch_challenge", "")
                if isinstance(tch, list):
                    self.touch_challenge_str = bytes(tch).hex()
                elif isinstance(tch, str):
                    self.touch_challenge_str = tch

                self.round_duration = data.get("round_duration_secs", 30)
                self.round_time_remaining = data.get("time_remaining_secs", 30)
                self.active_miners_count = data.get("active_miners_count", 0)
                if hasattr(self, "lbl_round_timer"):
                    self.lbl_round_timer.config(text=f"{format_time_human(self.round_time_remaining)} / {format_time_human(self.round_duration)}")
                    self.lbl_round_miners.config(text=f"Mineros participando: {self.active_miners_count} | Tus participaciones: {self.your_shares}")

                self.lbl_block_diff.config(text=f"#{self.current_height} ({self.current_diff_bits}b)")
                self.lbl_reward.config(text=f"{self.current_reward:.4f} BIC")
                return True
        except Exception as e:
            return False

    def _mining_worker(self, worker_id):
        # Staggered nonces per thread
        nonce = worker_id * 1000000 + (int(time.time() * 1000) % 500000)
        miner_addr = self.ent_address.get().strip()

        while self.is_mining:
            # Check 120s Human Touch presence
            if (time.time() - self.last_human_touch) > TARGET_VALIDITY_WINDOW:
                time.sleep(0.4)
                continue

            if not self.challenge_bytes:
                time.sleep(0.5)
                continue

            # Batch 5000 hashes
            for _ in range(5000):
                if not self.is_mining:
                    break

                # If cooldown is active, throttle so threads don't burn CPU generating rejected solutions
                if self.cooldown_until > time.time():
                    time.sleep(0.25)
                    break

                buf = self.challenge_bytes + miner_addr.encode("utf-8") + struct.pack("<Q", nonce) + b"_BIC_HUMAN_MINED"
                h = hashlib.sha256(buf).digest()

                if check_difficulty_bits(h, self.current_diff_bits):
                    self._on_block_found(nonce, h, miner_addr)
                    # Advance nonce to prevent re-submitting same solution
                    nonce += 10000
                    # Stagger share finding in collaborative mode to avoid burning CPU
                    time.sleep(3.5)
                    break

                nonce += 1
                self.total_hashes += 1

    def _on_block_found(self, winning_nonce, hash_bytes, miner_addr):
        with self.submit_lock:
            now = time.time()
            rem_cd = int(self.cooldown_until - now)
            if rem_cd > 0:
                if now - self.last_cooldown_log > 3.0:
                    self._log(f"⏳ Cooldown de IP activo: esperando {rem_cd}s antes de enviar nuevo bloque...", "orange")
                    self.last_cooldown_log = now
                return

            if self.last_solved_height == self.current_height and self.last_solved_height > 0:
                return

            calc_timestamp = int(self.server_time_sync + (time.time() - self.server_time_fetch_local))
            self._log(f"✨ [WINNER] Nonce {winning_nonce} satisfies {self.current_diff_bits} zero bits! Submitting...", "gold")

            payload = {
                "miner_address": miner_addr,
                "nonce": winning_nonce,
                "hardware_id": f"BIC-DESKTOP-{socket.gethostname()}",
                "human_touch_proof": calc_timestamp,
                "touch_challenge": self.touch_challenge_str,
                "touch_entropy": self.touch_entropy_accumulator if self.touch_entropy_accumulator > 0 else 666
            }

            try:
                req = urllib.request.Request(
                    f"{DEFAULT_NODE_URL}/api/mining/submit",
                    data=json.dumps(payload).encode("utf-8"),
                    headers={"Content-Type": "application/json", "User-Agent": "BicDesktopMiner/0.666"},
                    method="POST"
                )
                with urllib.request.urlopen(req, timeout=4) as resp:
                    res_data = json.loads(resp.read().decode())
                    status = res_data.get("status")

                    if status == "share_accepted":
                        self.your_shares = res_data.get("your_shares", self.your_shares + 1)
                        b_height = res_data.get("height", self.current_height)
                        rem_s = res_data.get("time_remaining_secs", 0)
                        dur_s = res_data.get("round_duration_secs", 30)
                        act_cnt = res_data.get("active_miners_count", 1)

                        if hasattr(self, "lbl_round_timer"):
                            self.lbl_round_timer.config(text=f"{format_time_human(rem_s)} / {format_time_human(dur_s)}")
                            self.lbl_round_miners.config(text=f"Mineros participando: {act_cnt} | Tus participaciones: {self.your_shares}")
                        self._log(f"⏱️ [RONDA #{b_height}] Participación aceptada! Shares: {self.your_shares} | Mineros: {act_cnt} | Restan: {format_time_human(rem_s)}", "cyan")

                    elif status == "block_sealed":
                        self.blocks_mined += 1
                        b_height = res_data.get("height", self.current_height)
                        total_rew = res_data.get("total_reward_bic", self.current_reward)
                        b_hash = res_data.get("block_hash", hash_bytes.hex())[:16]
                        payouts_cnt = res_data.get("payouts_count", 1)

                        self._log(f"🎉🎉🎉 BLOQUE COLABORATIVO #{b_height} SELLADO! Mineros: {payouts_cnt} | Recompensa Total: {total_rew:.4f} BIC (Hash: {b_hash}...)", "green")
                        self.lbl_blocks_mined.config(text=f"{self.blocks_mined} BLOCKS")
                        self.your_shares = 0
                        self._fetch_mining_job()
                    else:
                        self._log(f"❌ Submission rejected: {res_data}", "red")
            except urllib.error.HTTPError as e:
                try:
                    err_content = e.read().decode()
                    if "finalizada" in err_content or "Invalid mining solution nonce" in err_content or "RoundExpired" in err_content:
                        self._log("🔄 Ronda completada por la red. Sincronizando automáticamente al nuevo bloque...", "orange")
                        self.your_shares = 0
                        self._fetch_mining_job()
                    elif "DuplicateNonce" in err_content or "ya ha sido registrado" in err_content:
                        self._log("⚠️ Nonce ya registrado previamente. Continuando búsqueda de nuevos nonces...", "orange")
                    elif "Por favor espera" in err_content:
                        import re
                        m = re.search(r"espera (\d+)s", err_content)
                        wait_s = int(m.group(1)) if m else 15
                        self.cooldown_until = time.time() + wait_s
                        self._log(f"⏳ Cooldown de IP activo: esperando {wait_s}s antes de enviar nuevo bloque.", "orange")
                        self._fetch_mining_job()
                    else:
                        self._log(f"❌ Error {e.code}: {err_content}", "red")
                except Exception:
                    self._log(f"❌ HTTP Error {e.code}", "red")
            except Exception as e:
                self._log(f"❌ Network error submitting block: {e}", "red")

    # ESP32 Serial Monitor (USB Bridge)
    def toggle_esp32_serial(self):
        if not HAS_SERIAL:
            messagebox.showerror("Pyserial Missing", "pyserial library is required for ESP32 monitor. Install with: pip install pyserial")
            return

        if not self.serial_running:
            port = self.cbo_serial.get().strip()
            try:
                self.serial_conn = serial.Serial(port, 115200, timeout=1)
                self.serial_running = True
                self.btn_serial.config(text="Disconnect", bg="#d91e36")
                self.lbl_serial_stat.config(text=f"Connected ({port})", fg="#00ff88")
                self._log(f"Opened ESP32 serial bridge on {port} (115200 baud)", "cyan")

                self.serial_thread = threading.Thread(target=self._serial_read_loop, daemon=True)
                self.serial_thread.start()
            except Exception as e:
                messagebox.showerror("Serial Error", f"Could not open {port}: {e}")
        else:
            self.serial_running = False
            if self.serial_conn:
                try:
                    self.serial_conn.close()
                except Exception:
                    pass
            self.btn_serial.config(text="Connect ESP32", bg="#222533")
            self.lbl_serial_stat.config(text="Disconnected", fg="#778899")
            self._log("ESP32 serial monitor disconnected.", "gray")

    def _serial_read_loop(self):
        while self.serial_running and self.serial_conn and self.serial_conn.is_open:
            try:
                line = self.serial_conn.readline()
                if line:
                    decoded = line.decode("utf-8", errors="replace").strip()
                    if decoded:
                        self._log(f"[ESP32] {decoded}", "cyan")
            except Exception:
                break

    # Background UI Update Loop
    def _start_background_loops(self):
        def loop_tick():
            self._update_touch_timer_ui()
            
            # Calculate Hashrate
            if self.is_mining and self.start_time > 0:
                elapsed = time.time() - self.start_time
                if elapsed > 0:
                    self.current_hashrate = self.total_hashes / elapsed
                    self.lbl_hashrate.config(text=f"{self.current_hashrate:,.1f} H/s")
                    self.hashrate_history.append(self.current_hashrate)
                    if len(self.hashrate_history) > 30:
                        self.hashrate_history.pop(0)
                    self._draw_graph()

            self.root.after(500, loop_tick)

        def poll_node_job():
            ok = self._fetch_mining_job()
            if ok:
                self.lbl_daemon_status.config(text="● NODE: MAINNET 666", fg="#00ff88")
            else:
                self.lbl_daemon_status.config(text="● NODE: OFFLINE", fg="#ff2a44")
            self.root.after(3000, poll_node_job)

        self.root.after(200, loop_tick)
        self.root.after(100, poll_node_job)

    def _draw_graph(self):
        c = self.canvas_graph
        w = c.winfo_width()
        h = c.winfo_height()
        if w <= 10 or h <= 10:
            return

        c.delete("all")
        # Background Grid lines
        for y_pct in [0.25, 0.5, 0.75]:
            c.create_line(0, int(h * y_pct), w, int(h * y_pct), fill="#141622", width=1)

        max_hr = max(self.hashrate_history) if max(self.hashrate_history) > 0 else 100.0
        n_pts = len(self.hashrate_history)
        step_x = w / max(1, n_pts - 1)

        points = []
        for idx, hr in enumerate(self.hashrate_history):
            x = idx * step_x
            y = h - (hr / max_hr) * (h - 10) - 5
            points.extend([x, y])

        if len(points) >= 4:
            # Filled area under graph
            polygon_pts = [0, h] + points + [w, h]
            c.create_polygon(polygon_pts, fill="#1f141a", outline="")
            # Glowing Line
            c.create_line(points, fill="#ff2a44", width=2, smooth=True)

        # Draw peak text
        c.create_text(w - 8, 8, text=f"Peak: {max_hr:,.0f} H/s", fill="#8899aa", font=("Helvetica", 7), anchor="ne")

def main():
    root = tk.Tk()
    app = BicDesktopMinerApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
