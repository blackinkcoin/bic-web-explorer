@echo off
title Black Ink Coin - Guardian de la Red (WSL2)
color 0A
echo Iniciando nodo Guardian bicd mediante WSL2...
wsl ./bicd --data-dir .bic_ledger
pause
