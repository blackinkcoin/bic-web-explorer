@echo off
title Black Ink Coin - Guardian de la Red (Docker)
color 0D
echo Iniciando nodo Guardian bicd con Docker...
docker run -d -p 6660:6660 -v %cd%/.bic_ledger:/root/.bic_ledger --name bicd-node blackinkcoin/bicd:latest
pause
