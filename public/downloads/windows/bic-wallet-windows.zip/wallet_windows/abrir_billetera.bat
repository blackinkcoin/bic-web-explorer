@echo off
start billetera_fria_offline.html
